# -*- tcl -*-
# Tcl package index file, version 1.1
#
package ifneeded tclcompiler 2.0a0 \
    [list load [file join $dir libtclcompiler2.0a0.so] [string totitle tclcompiler]]
