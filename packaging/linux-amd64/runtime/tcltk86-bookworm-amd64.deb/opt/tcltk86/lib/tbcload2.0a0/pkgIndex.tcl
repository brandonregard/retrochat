# -*- tcl -*-
# Tcl package index file, version 1.1
#
package ifneeded tbcload 2.0a0 \
    [list load [file join $dir libtbcload2.0a0.so] [string totitle tbcload]]
