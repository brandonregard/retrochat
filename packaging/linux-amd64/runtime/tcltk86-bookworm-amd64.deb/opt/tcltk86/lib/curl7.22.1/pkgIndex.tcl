#
# Tcl package index file
#
package ifneeded curl 7.22.1 \
    "[list load [file join $dir libcurl7.22.1.so] curl]; [list source [file join $dir tclcurl.tcl]]"
