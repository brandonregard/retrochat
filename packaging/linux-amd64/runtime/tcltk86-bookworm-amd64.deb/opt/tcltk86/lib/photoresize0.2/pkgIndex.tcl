#
# Tcl package index file
#
package ifneeded photoresize 0.2 \
    [list load [file join $dir libphotoresize0.2.so] photoresize]
