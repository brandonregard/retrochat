if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded zlibtcl 1.3.2 [list load [file join $dir libtcl9zlibtcl1.3.2.so]]
} else {
    package ifneeded zlibtcl 1.3.2 [list load [file join $dir libzlibtcl1.3.2.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded pngtcl 1.6.55 [list load [file join $dir libtcl9pngtcl1.6.55.so]]
} else {
    package ifneeded pngtcl 1.6.55 [list load [file join $dir libpngtcl1.6.55.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded tifftcl 4.7.1 [list load [file join $dir libtcl9tifftcl4.7.1.so]]
} else {
    package ifneeded tifftcl 4.7.1 [list load [file join $dir libtifftcl4.7.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded jpegtcl 10.0.0 [list load [file join $dir libtcl9jpegtcl10.0.0.so]]
} else {
    package ifneeded jpegtcl 10.0.0 [list load [file join $dir libjpegtcl10.0.0.so]]
}
# -*- tcl -*- Tcl package index file
# --- --- --- Handcrafted, final generation by configure.

if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::base 2.1.1 [list load [file join $dir libtcl9tkimg2.1.1.so]]
} else {
    package ifneeded img::base 2.1.1 [list load [file join $dir libtkimg2.1.1.so]]
}
# Compatibility hack. When asking for the old name of the package
# then load all format handlers and base libraries provided by tkImg.
# Actually we ask only for the format handlers, the required base
# packages will be loaded automatically through the usual package
# mechanism.

# When reading images without specifying it's format (option -format),
# the available formats are tried in reversed order as listed here.
# Therefore file formats with some "magic" identifier, which can be
# recognized safely, should be added at the end of this list.

package ifneeded Img 2.1.1 {
    package require img::window
    package require img::tga
    package require img::ico
    package require img::pcx
    package require img::sgi
    package require img::sun
    package require img::xbm
    package require img::xpm
    package require img::jpeg
    package require img::png
    package require img::tiff
    package require img::bmp
    package require img::ppm
    package require img::pixmap
    package provide Img 2.1.1
}

if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::bmp 2.1.1 [list load [file join $dir libtcl9tkimgbmp2.1.1.so]]
} else {
    package ifneeded img::bmp 2.1.1 [list load [file join $dir libtkimgbmp2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::gif 2.1.1 [list load [file join $dir libtcl9tkimggif2.1.1.so]]
} else {
    package ifneeded img::gif 2.1.1 [list load [file join $dir libtkimggif2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::ico 2.1.1 [list load [file join $dir libtcl9tkimgico2.1.1.so]]
} else {
    package ifneeded img::ico 2.1.1 [list load [file join $dir libtkimgico2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::jpeg 2.1.1 [list load [file join $dir libtcl9tkimgjpeg2.1.1.so]]
} else {
    package ifneeded img::jpeg 2.1.1 [list load [file join $dir libtkimgjpeg2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::pcx 2.1.1 [list load [file join $dir libtcl9tkimgpcx2.1.1.so]]
} else {
    package ifneeded img::pcx 2.1.1 [list load [file join $dir libtkimgpcx2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::pixmap 2.1.1 [list load [file join $dir libtcl9tkimgpixmap2.1.1.so]]
} else {
    package ifneeded img::pixmap 2.1.1 [list load [file join $dir libtkimgpixmap2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::png 2.1.1 [list load [file join $dir libtcl9tkimgpng2.1.1.so]]
} else {
    package ifneeded img::png 2.1.1 [list load [file join $dir libtkimgpng2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::ppm 2.1.1 [list load [file join $dir libtcl9tkimgppm2.1.1.so]]
} else {
    package ifneeded img::ppm 2.1.1 [list load [file join $dir libtkimgppm2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::ps 2.1.1 [list load [file join $dir libtcl9tkimgps2.1.1.so]]
} else {
    package ifneeded img::ps 2.1.1 [list load [file join $dir libtkimgps2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::sgi 2.1.1 [list load [file join $dir libtcl9tkimgsgi2.1.1.so]]
} else {
    package ifneeded img::sgi 2.1.1 [list load [file join $dir libtkimgsgi2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::sun 2.1.1 [list load [file join $dir libtcl9tkimgsun2.1.1.so]]
} else {
    package ifneeded img::sun 2.1.1 [list load [file join $dir libtkimgsun2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::tga 2.1.1 [list load [file join $dir libtcl9tkimgtga2.1.1.so]]
} else {
    package ifneeded img::tga 2.1.1 [list load [file join $dir libtkimgtga2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::tiff 2.1.1 [list load [file join $dir libtcl9tkimgtiff2.1.1.so]]
} else {
    package ifneeded img::tiff 2.1.1 [list load [file join $dir libtkimgtiff2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::window 2.1.1 [list load [file join $dir libtcl9tkimgwindow2.1.1.so]]
} else {
    package ifneeded img::window 2.1.1 [list load [file join $dir libtkimgwindow2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::xbm 2.1.1 [list load [file join $dir libtcl9tkimgxbm2.1.1.so]]
} else {
    package ifneeded img::xbm 2.1.1 [list load [file join $dir libtkimgxbm2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::xpm 2.1.1 [list load [file join $dir libtcl9tkimgxpm2.1.1.so]]
} else {
    package ifneeded img::xpm 2.1.1 [list load [file join $dir libtkimgxpm2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::dted 2.1.1 [list load [file join $dir libtcl9tkimgdted2.1.1.so]]
} else {
    package ifneeded img::dted 2.1.1 [list load [file join $dir libtkimgdted2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::raw 2.1.1 [list load [file join $dir libtcl9tkimgraw2.1.1.so]]
} else {
    package ifneeded img::raw 2.1.1 [list load [file join $dir libtkimgraw2.1.1.so]]
}
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded img::flir 2.1.1 [list load [file join $dir libtcl9tkimgflir2.1.1.so]]
} else {
    package ifneeded img::flir 2.1.1 [list load [file join $dir libtkimgflir2.1.1.so]]
}
