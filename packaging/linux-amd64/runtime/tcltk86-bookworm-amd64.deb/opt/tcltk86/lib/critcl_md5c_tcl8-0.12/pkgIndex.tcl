if {![package vsatisfies [package provide Tcl] 8.6]} {return}
package ifneeded critcl_md5c 0.12 [list ::apply {dir {
    source [file join $dir critcl-rt.tcl]
    set path [file join $dir [::critcl::runtime::MapPlatform]]
    set ext [info sharedlibextension]
    set lib [file join $path "md5c$ext"]
    load $lib Md5c
    package provide critcl_md5c 0.12
}} $dir]
