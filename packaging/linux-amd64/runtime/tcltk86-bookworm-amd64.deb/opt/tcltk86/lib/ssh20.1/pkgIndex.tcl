#
# Tcl package index file
#
package ifneeded ssh2 0.1 \
    [list load [file join $dir libssh20.1.so] ssh2]
