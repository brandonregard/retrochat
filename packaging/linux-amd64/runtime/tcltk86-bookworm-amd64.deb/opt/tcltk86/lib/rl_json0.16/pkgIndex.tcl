# -*- tcl -*-
# Tcl package index file, version 1.1
#
if {[package vsatisfies [package provide Tcl] 9.0-]} {
    package ifneeded rl_json 0.16 \
	    [list apply {dir {load [file join $dir libtcl9rl_json0.16.so] [string totitle rl_json]}} $dir]
} else {
    package ifneeded rl_json 0.16 \
	    [list apply {dir {load [file join $dir librl_json0.16.so] [string totitle rl_json]}} $dir]
}
interp alias {} rljson {} rl_json::json
