#
# Tcl package index file
#
package ifneeded parse_args 0.6 \
    [list load [file join $dir libparse_args0.6.so] [string totitle parse_args]]
