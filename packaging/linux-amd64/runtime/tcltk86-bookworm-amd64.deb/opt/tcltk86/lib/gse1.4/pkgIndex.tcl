package ifneeded gse 1.4 {
    package provide gse 1.4
    namespace eval gse {
        variable tcl_release "20"
        variable build_os "Debian GNU/Linux 12 (bookworm)"
        variable build_kernelname "Linux"
        variable build_kernelrelease "6.1.0-49-amd64"
        variable build_kernelversion "#1 SMP PREEMPT_DYNAMIC Debian 6.1.174-1 (2026-05-26)"
        variable build_nodename "d12-gitlab-runner"
        variable build_machine "x86_64"
        variable build_date "Sat 11 Jul 01:36:47 UTC 2026"
        variable git_hash "1a9f0e4ef13d3b060ce0b5af7121a8a731c48e5e"
        variable gcc_version "2.2.0-14"
    }
}
