#
# Tcl package index file for ktvisa 1.0.0
#
# This file is sourced either when an application starts up or
# by a "package unknown" script.  It invokes the
# "package ifneeded" command to set up package-related
# information so that packages will be loaded automatically
# in response to "package require" commands.  When this
# script is sourced, the variable $dir must contain the
# full path name of this file's directory.
#

package ifneeded ktvisa 1.0.0 [list apply {dir {
    load [file join $dir libktvisa1.0.0.so] ktvisa
}} $dir]
